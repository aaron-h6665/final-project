# Phase Three (Final Phase) of Comp Sci 471: Cryptography

## We had to option to explore whatever paradigm we wanted. I chose Attacks, and specifically a basic differential cryptanalysis attack.

This repository contains the code that I have submitted for Phase Three of my Computer Science Class of Cryptography. The main file is the Jupyter Notebook (differential_cryptanalysis.ipynb) that contains the tutorial that I created for the interactive code demo, our final project. There are a few images that I have used as well in this repository.

## How to tweak this project for your own uses

Feel free to take this code and test/improve the differential cryptanalysis attack for yourself.

## Find a bug?

If you found an issue or would like to submit an improvement ot this project, please notify me by email: ahuang25@andover.edu.

## Work in Progress
* I will try to work on a more complex attack on my own time
* I will try to add a bit more on AES vs. DES which is about security against differential cryptanalysis attacks.
